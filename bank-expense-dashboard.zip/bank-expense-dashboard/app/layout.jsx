import "./globals.css";

export const metadata = {
  title: "Bank Expense Dashboard",
  description: "Personal bank income and expense tracking dashboard",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
