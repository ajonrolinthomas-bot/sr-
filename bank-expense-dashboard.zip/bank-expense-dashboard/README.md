# Bank Expense Dashboard

Next.js personal bank income and expense tracking dashboard.

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Upload this folder to GitHub.
2. Go to Vercel > Add New Project.
3. Import the GitHub repo.
4. Framework preset: Next.js.
5. Build command: `npm run build`.
6. Output directory: leave empty.
7. Click Deploy.
